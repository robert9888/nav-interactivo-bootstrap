   $(document).ready(function(){

  $('.parallax').parallax();
      $('.slider').slider({'transition':800,'indicators':false,'height':450});

     $('.next').click(function() {
 $('.slider').slider('next');
});
$('.prev').click(function() {
 $('.slider').slider('prev');
});

    });


 